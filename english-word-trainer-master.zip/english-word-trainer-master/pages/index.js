import React from 'react';
import Home from '../components/Home';

const Main = () => {
  return (
    <Home />
  )
};

export default Main;
