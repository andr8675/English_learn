import { DEFAULT_LANG, FIREBASE_CONFIG } from './config';

export {
  DEFAULT_LANG,
  FIREBASE_CONFIG,
};
