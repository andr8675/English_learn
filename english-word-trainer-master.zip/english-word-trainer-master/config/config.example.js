export const DEFAULT_LANG = 'en';

export const FIREBASE_CONFIG = {
  apiKey: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  authDomain: 'your-firebase-app.firebaseapp.com',
  databaseURL: 'https://your-firebase-app.firebaseio.com',
  storageBucket: 'your-firebase-app.appspot.com',
  messagingSenderId: 'xxxxxxxxxxxx'
}
