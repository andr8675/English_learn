import SingleWord from './SingleWord';

export default SingleWord;
