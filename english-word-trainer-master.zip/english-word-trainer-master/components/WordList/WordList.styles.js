import styled from 'styled-components';

export const WordListWrapper = styled.div`
  width: 100%;
  height: 95%;
  position: relative;
`;
